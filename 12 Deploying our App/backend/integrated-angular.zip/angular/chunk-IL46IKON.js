import{Oa as a}from"./chunk-KVVFFMSM.js";export{a as AuthModule};
